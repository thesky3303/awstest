(function () {
  const THEATERS_MAIN_CSS_PATH = '/css/theaters/theaters_main.css';
  const THEATERS_DETAIL_SCRIPT_PATH = '/js/theaters/theaters_detail.js';
  const MOVIES_API_PATH = '/movies';
  const THEATERS_LIST_API_PATH = '/theaters';
  const THEATER_DETAIL_API_PREFIX = '/theater';

  // TODO:
  // 잔여좌석 전용 py가 나중에 생기면 여기만 연결하면 됩니다.
  // 기대 응답 형식: { "101": 28, "102": 30 }
  // 즉 schedule_id = remain_count 맵입니다.
  // 현재 py는 아직 없으므로, 호출 실패는 무시하고 theaters_read.py가 주는 기본 값으로 표시합니다.
  const THEATERS_REMAIN_OVERRIDES_API_PATH = '/theaters/remains';

  const DEFAULT_SEAT_ROWS = 3;
  const DEFAULT_SEAT_COLS = 10;

  const state = {
    movies: [],
    theaterList: [],
    theaterDetailMap: {},
    reservedSeatsMap: {},
    remainOverrides: {},
    selectedRegion: '',
    selectedTheaterId: null,
    selectedMovieId: null,
    selectedDateKey: '',
    selectedSpecial: 'ALL',
    selectedTimeBand: 'ALL'
  };

  function ensureMainCss() {
    if (window.APP_RUNTIME && typeof window.APP_RUNTIME.ensureStyle === 'function') {
      return window.APP_RUNTIME.ensureStyle(THEATERS_MAIN_CSS_PATH);
    }

    const exists = document.querySelector(`link[href="${THEATERS_MAIN_CSS_PATH}"]`);
    if (exists) return Promise.resolve(exists);

    const link = document.createElement('link');
    link.rel = 'stylesheet';
    link.href = THEATERS_MAIN_CSS_PATH;
    document.head.appendChild(link);
    return Promise.resolve(link);
  }

  function ensureDetailScript() {
    if (window.APP_RUNTIME && typeof window.APP_RUNTIME.ensureScript === 'function') {
      return window.APP_RUNTIME.ensureScript(THEATERS_DETAIL_SCRIPT_PATH);
    }

    const exists = document.querySelector(`script[src="${THEATERS_DETAIL_SCRIPT_PATH}"]`);
    if (exists) return Promise.resolve(exists);

    return new Promise((resolve, reject) => {
      const script = document.createElement('script');
      script.src = THEATERS_DETAIL_SCRIPT_PATH;
      script.defer = true;
      script.addEventListener('load', () => resolve(script), { once: true });
      script.addEventListener('error', () => reject(new Error(`script load fail: ${THEATERS_DETAIL_SCRIPT_PATH}`)), { once: true });
      document.body.appendChild(script);
    });
  }

  function ensureMountPoint() {
    if (window.APP_RUNTIME && typeof window.APP_RUNTIME.ensureMainBody === 'function') {
      return window.APP_RUNTIME.ensureMainBody();
    }

    let mount = document.getElementById('main-body');
    if (!mount) {
      mount = document.createElement('div');
      mount.id = 'main-body';
      document.body.appendChild(mount);
    }
    return mount;
  }

  function clearPrimarySections() {
    if (window.APP_RUNTIME && typeof window.APP_RUNTIME.resetPrimarySections === 'function') {
      window.APP_RUNTIME.resetPrimarySections();
      return;
    }

    const mount = ensureMountPoint();
    mount.innerHTML = '';
    mount.style.display = '';

    const second = document.getElementById('main-body2');
    if (second) second.remove();
  }

  function escapeHtml(value) {
    if (value === null || value === undefined) return '';
    return String(value)
      .replaceAll('&', '&amp;')
      .replaceAll('<', '&lt;')
      .replaceAll('>', '&gt;')
      .replaceAll('"', '&quot;')
      .replaceAll("'", '&#39;');
  }

  function toInt(value) {
    const parsed = Number(value);
    return Number.isFinite(parsed) ? Math.trunc(parsed) : 0;
  }

  function parseDateValue(value) {
    if (!value) return null;
    if (value instanceof Date) return Number.isNaN(value.getTime()) ? null : value;

    const normalized = String(value).trim().replace(' ', 'T');
    const date = new Date(normalized);
    if (!Number.isNaN(date.getTime())) return date;

    const fallback = new Date(String(value).trim());
    return Number.isNaN(fallback.getTime()) ? null : fallback;
  }

  function pad2(value) {
    return String(value).padStart(2, '0');
  }

  function toDateKey(value) {
    const date = parseDateValue(value);
    if (!date) return '';
    return `${date.getFullYear()}-${pad2(date.getMonth() + 1)}-${pad2(date.getDate())}`;
  }

  function formatMonthLabel(value) {
    const date = parseDateValue(value);
    if (!date) return '';
    return `${date.getMonth() + 1}월`;
  }

  function formatDayLabel(value) {
    const date = parseDateValue(value);
    if (!date) return null;

    const names = ['일', '월', '화', '수', '목', '금', '토'];
    return {
      day: date.getDate(),
      week: names[date.getDay()],
      full: `${date.getFullYear()}-${pad2(date.getMonth() + 1)}-${pad2(date.getDate())}`
    };
  }

  function formatTimeLabel(value) {
    const date = parseDateValue(value);
    if (!date) return '--:--';
    return `${pad2(date.getHours())}:${pad2(date.getMinutes())}`;
  }

  function addMinutes(dateValue, minutes) {
    const date = parseDateValue(dateValue);
    if (!date) return null;
    return new Date(date.getTime() + Number(minutes || 0) * 60 * 1000);
  }

  function formatRangeLabel(schedule, movie) {
    if (schedule.start_time && schedule.end_time) {
      return `${schedule.start_time}~${schedule.end_time}`;
    }

    const start = parseDateValue(schedule.show_date);
    const runtime = toInt(movie && movie.runtime_minutes ? movie.runtime_minutes : schedule.runtime_minutes || 120);
    const end = addMinutes(start, runtime);
    return `${formatTimeLabel(start)}~${formatTimeLabel(end)}`;
  }

  function getTimeBand(dateValue) {
    const date = parseDateValue(dateValue);
    if (!date) return 'ALL';
    const hour = date.getHours();
    if (hour >= 23 || hour < 5) return 'LATE';
    if (hour >= 19) return 'AFTER_19';
    if (hour >= 13) return 'AFTER_13';
    return 'ALL';
  }

  function buildSpecialTag(hallName) {
    const value = String(hallName || '').toUpperCase();
    if (value.includes('ATMOS')) return 'ATMOS';
    if (value.includes('LASER')) return 'LASER';
    if (value.includes('IMAX')) return 'IMAX';
    return 'GENERAL';
  }

  function deriveRegionNameFromAddress(address) {
    const text = String(address || '').trim();
    if (!text) return '기타';
    if (text.includes('서울')) return '서울';
    if (text.includes('경기') || text.includes('인천')) return '경기/인천';
    return '기타';
  }

  function stripSuffix(text) {
    const value = String(text || '').trim();
    if (!value) return '';

    return value
      .replace(/특별시$/u, '')
      .replace(/광역시$/u, '')
      .replace(/특별자치시$/u, '')
      .replace(/특별자치도$/u, '')
      .replace(/자치시$/u, '')
      .replace(/자치도$/u, '')
      .replace(/도$/u, '')
      .replace(/시$/u, '')
      .replace(/구$/u, '')
      .replace(/군$/u, '')
      .replace(/동$/u, '')
      .trim();
  }

  function deriveTheaterNameFromAddress(address, fallbackId) {
    const text = String(address || '').trim();
    if (!text) return `극장 ${fallbackId}`;

    const tokens = text.split(/\s+/).filter(Boolean);
    if (!tokens.length) return `극장 ${fallbackId}`;

    const preferred = tokens.find((token) => /동$/u.test(token))
      || tokens.find((token) => /(구|시|군)$/u.test(token))
      || tokens[tokens.length - 1];

    const stripped = stripSuffix(preferred);
    return stripped || preferred || `극장 ${fallbackId}`;
  }

  async function loadMovies() {
    if (typeof readApi !== 'function') return [];

    try {
      const response = await readApi(MOVIES_API_PATH);
      if (!Array.isArray(response)) return [];

      return response
        .filter((movie) => String(movie.status || '').toUpperCase() === 'ACTIVE')
        .filter((movie) => String(movie.hide || 'N').toUpperCase() === 'N')
        .sort((a, b) => toInt(a.movie_id) - toInt(b.movie_id));
    } catch (error) {
      console.warn('movies load fail', error);
      return [];
    }
  }

  function buildMovieMap(movies) {
    const movieMap = new Map();
    (Array.isArray(movies) ? movies : []).forEach((movie) => {
      movieMap.set(toInt(movie.movie_id), movie);
    });
    return movieMap;
  }

  function normalizeTheatersListFromApi(raw) {
    const list = Array.isArray(raw) ? raw : [];

    return list.map((item, index) => ({
      theater_id: toInt(item.theater_id || index + 1),
      address: String(item.address || '').trim(),
      region_name: deriveRegionNameFromAddress(item.address),
      theater_name: deriveTheaterNameFromAddress(item.address, index + 1),
      halls: Array.isArray(item.halls) ? item.halls.map((hall, hallIndex) => ({
        hall_id: toInt(hall.hall_id || hallIndex + 1),
        theater_id: toInt(item.theater_id || index + 1),
        hall_name: String(hall.hall_name || hall.name || 'A관').trim() || 'A관',
        total_seats: Math.max(1, toInt(hall.total_seats || DEFAULT_SEAT_ROWS * DEFAULT_SEAT_COLS)),
        seat_rows: Math.max(1, toInt(hall.seat_rows || DEFAULT_SEAT_ROWS)),
        seat_cols: Math.max(1, toInt(hall.seat_cols || DEFAULT_SEAT_COLS))
      })) : []
    }));
  }

  function normalizeTheaterDetailFromApi(raw, theaterBase) {
    const base = theaterBase && typeof theaterBase === 'object' ? theaterBase : {};
    const theater = raw && raw.theater && typeof raw.theater === 'object' ? raw.theater : {};
    const movies = Array.isArray(raw && raw.movies) ? raw.movies : [];

    return {
      theater: {
        theater_id: toInt(theater.theater_id || base.theater_id),
        theater_name: String(base.theater_name || deriveTheaterNameFromAddress(theater.address || base.address, base.theater_id || theater.theater_id || 0)).trim(),
        region_name: String(base.region_name || deriveRegionNameFromAddress(theater.address || base.address)).trim(),
        address: String(theater.address || base.address || '').trim(),
        halls: Array.isArray(theater.halls) ? theater.halls.map((hall, index) => ({
          hall_id: toInt(hall.hall_id || index + 1),
          theater_id: toInt(theater.theater_id || base.theater_id),
          hall_name: String(hall.hall_name || hall.name || 'A관').trim() || 'A관',
          total_seats: Math.max(1, toInt(hall.total_seats || DEFAULT_SEAT_ROWS * DEFAULT_SEAT_COLS)),
          seat_rows: Math.max(1, toInt(hall.seat_rows || DEFAULT_SEAT_ROWS)),
          seat_cols: Math.max(1, toInt(hall.seat_cols || DEFAULT_SEAT_COLS))
        })) : Array.isArray(base.halls) ? base.halls.slice() : []
      },
      movies: movies.map((movie) => ({
        movie_id: toInt(movie.movie_id),
        title: String(movie.title || '').trim() || `영화 ${movie.movie_id}`,
        runtime_minutes: Math.max(0, toInt(movie.runtime_minutes || 0)),
        dates: Array.isArray(movie.dates) ? movie.dates.map((date) => ({
          show_date: String(date.show_date || '').trim(),
          month: Math.max(0, toInt(date.month || 0)),
          day: Math.max(0, toInt(date.day || 0)),
          week_day: String(date.week_day || '').trim(),
          schedules: Array.isArray(date.schedules) ? date.schedules.map((schedule) => ({
            schedule_id: toInt(schedule.schedule_id),
            hall_id: toInt(schedule.hall_id),
            hall_name: String(schedule.hall_name || '상영관').trim() || '상영관',
            show_date: String(schedule.show_date || '').trim(),
            start_time: String(schedule.start_time || '').trim(),
            end_time: String(schedule.end_time || '').trim(),
            runtime_minutes: Math.max(0, toInt(schedule.runtime_minutes || movie.runtime_minutes || 0)),
            total_count: Math.max(0, toInt(schedule.total_count || DEFAULT_SEAT_ROWS * DEFAULT_SEAT_COLS)),
            remain_count: Number.isFinite(Number(schedule.remain_count)) ? Math.max(0, toInt(schedule.remain_count)) : null,
            status: String(schedule.status || 'OPEN').toUpperCase(),
            price: Math.max(0, toInt(schedule.price || 14000)),
            special_tag: String(schedule.special_tag || '').trim().toUpperCase(),
            __demo: Boolean(schedule.__demo)
          })) : []
        })) : []
      }))
    };
  }

  async function loadInitialDataset() {
    if (typeof readApi !== 'function') {
      throw new Error('readApi가 없습니다.');
    }

    const listResponse = await readApi(THEATERS_LIST_API_PATH);
    return normalizeTheatersListFromApi(listResponse);
  }

  function mergeMoviesFromDetail(detail) {
    if (!detail || !Array.isArray(detail.movies)) return;

    const movieMap = buildMovieMap(state.movies);
    detail.movies.forEach((movie) => {
      const movieId = toInt(movie.movie_id);
      if (!movieMap.has(movieId)) {
        const stub = {
          movie_id: movieId,
          title: movie.title,
          runtime_minutes: toInt(movie.runtime_minutes || 0),
          status: 'ACTIVE',
          hide: 'N'
        };
        state.movies.push(stub);
        movieMap.set(movieId, stub);
      }
    });

    state.movies.sort((a, b) => toInt(a.movie_id) - toInt(b.movie_id));
  }

  async function loadTheaterDetail(theaterId) {
    const key = String(theaterId);
    if (state.theaterDetailMap[key]) {
      return state.theaterDetailMap[key];
    }

    if (typeof readApi !== 'function') {
      throw new Error('readApi가 없습니다.');
    }

    const theaterBase = getTheaterById(theaterId);
    const response = await readApi(`${THEATER_DETAIL_API_PREFIX}/${theaterId}`);
    const normalized = normalizeTheaterDetailFromApi(response, theaterBase);
    state.theaterDetailMap[key] = normalized;
    mergeMoviesFromDetail(normalized);
    return normalized;
  }

  async function loadOptionalRemainOverrides() {
    if (typeof window.THEATERS_REMAIN_OVERRIDES_PROVIDER === 'function') {
      try {
        return normalizeRemainOverrides(await window.THEATERS_REMAIN_OVERRIDES_PROVIDER());
      } catch (error) {
        console.warn('remain overrides provider fail', error);
      }
    }

    if (typeof readApi !== 'function') {
      return {};
    }

    try {
      return normalizeRemainOverrides(await readApi(THEATERS_REMAIN_OVERRIDES_API_PATH));
    } catch (error) {
      // 잔여좌석 전용 py는 아직 없을 수 있으므로 여기서는 조용히 무시합니다.
      return {};
    }
  }

  function normalizeRemainOverrides(raw) {
    const source = raw && typeof raw === 'object' ? raw : {};
    const result = {};

    Object.keys(source).forEach((key) => {
      const parsed = Number(source[key]);
      if (Number.isFinite(parsed)) {
        result[String(key)] = Math.max(0, Math.trunc(parsed));
      }
    });

    return result;
  }

  function getRegions() {
    const regionMap = new Map();

    state.theaterList.forEach((theater) => {
      const key = theater.region_name || '기타';
      const count = regionMap.get(key) || 0;
      regionMap.set(key, count + 1);
    });

    return Array.from(regionMap.entries()).map(([name, count]) => ({ name, count }));
  }

  function getTheatersByRegion(regionName) {
    return state.theaterList.filter((theater) => theater.region_name === regionName);
  }

  function getTheaterById(theaterId) {
    return state.theaterList.find((item) => toInt(item.theater_id) === toInt(theaterId)) || null;
  }

  function getSelectedTheaterDetail() {
    return state.theaterDetailMap[String(state.selectedTheaterId)] || null;
  }

  function getSelectedMovie(detail) {
    if (!detail || !Array.isArray(detail.movies)) return null;
    return detail.movies.find((item) => toInt(item.movie_id) === toInt(state.selectedMovieId)) || null;
  }

  function getHallByIdFromDetail(detail, hallId) {
    if (!detail || !detail.theater || !Array.isArray(detail.theater.halls)) return null;
    return detail.theater.halls.find((item) => toInt(item.hall_id) === toInt(hallId)) || null;
  }

  function getAvailableDateKeys(detail, movieId) {
    if (!detail || !Array.isArray(detail.movies)) return [];

    const movie = detail.movies.find((item) => toInt(item.movie_id) === toInt(movieId));
    if (!movie || !Array.isArray(movie.dates)) return [];

    return movie.dates
      .map((item) => String(item.show_date || '').trim())
      .filter(Boolean)
      .sort();
  }

  function getDisplayRemainCount(schedule) {
    const scheduleId = String(schedule && schedule.schedule_id ? schedule.schedule_id : '');

    if (scheduleId && Object.prototype.hasOwnProperty.call(state.remainOverrides, scheduleId)) {
      return Math.max(0, toInt(state.remainOverrides[scheduleId]));
    }

    if (Number.isFinite(Number(schedule && schedule.remain_count))) {
      return Math.max(0, toInt(schedule.remain_count));
    }

    return Math.max(0, toInt(schedule && schedule.total_count));
  }

  function getSchedulesForSelection(detail) {
    const movie = getSelectedMovie(detail);
    if (!movie || !Array.isArray(movie.dates) || !state.selectedDateKey) return [];

    const dateEntry = movie.dates.find((item) => String(item.show_date || '').trim() === state.selectedDateKey);
    if (!dateEntry || !Array.isArray(dateEntry.schedules)) return [];

    return dateEntry.schedules
      .filter((schedule) => String(schedule.status || 'OPEN').toUpperCase() === 'OPEN')
      .filter((schedule) => {
        const specialTag = String(schedule.special_tag || buildSpecialTag(schedule.hall_name)).toUpperCase();
        if (state.selectedSpecial === 'ALL') return true;
        if (state.selectedSpecial === 'GENERAL') return specialTag === 'GENERAL';
        return specialTag === state.selectedSpecial;
      })
      .filter((schedule) => {
        if (state.selectedTimeBand === 'ALL') return true;
        return getTimeBand(schedule.show_date) === state.selectedTimeBand;
      })
      .slice()
      .sort((a, b) => String(a.show_date || '').localeCompare(String(b.show_date || '')));
  }

  async function ensureStateDefaults() {
    if (!state.theaterList.length) return;

    const regions = getRegions();
    if (!regions.length) return;

    if (!state.selectedRegion || !regions.some((item) => item.name === state.selectedRegion)) {
      state.selectedRegion = regions[0].name;
    }

    const theaters = getTheatersByRegion(state.selectedRegion);
    if (!theaters.length) return;

    if (!state.selectedTheaterId || !theaters.some((item) => toInt(item.theater_id) === toInt(state.selectedTheaterId))) {
      state.selectedTheaterId = toInt(theaters[0].theater_id);
    }

    const detail = await loadTheaterDetail(state.selectedTheaterId);
    const movies = Array.isArray(detail && detail.movies) ? detail.movies : [];

    if (movies.length) {
      if (!state.selectedMovieId || !movies.some((item) => toInt(item.movie_id) === toInt(state.selectedMovieId))) {
        state.selectedMovieId = toInt(movies[0].movie_id);
      }
    } else {
      state.selectedMovieId = null;
    }

    const dateKeys = state.selectedMovieId ? getAvailableDateKeys(detail, state.selectedMovieId) : [];
    if (dateKeys.length) {
      if (!state.selectedDateKey || !dateKeys.includes(state.selectedDateKey)) {
        const todayKey = toDateKey(new Date());
        state.selectedDateKey = dateKeys.includes(todayKey) ? todayKey : dateKeys[0];
      }
    } else {
      state.selectedDateKey = '';
    }
  }

  function buildLayoutHtml() {
    const theater = getTheaterById(state.selectedTheaterId);
    const detail = getSelectedTheaterDetail();
    const movie = getSelectedMovie(detail);
    const selectedDateInfo = formatDayLabel(state.selectedDateKey);

    return `
      <div class="theaters-booking-page">
        <aside class="theaters-booking-stepbar">
          <div class="theaters-booking-step is-active">
            <span class="theaters-booking-step-no">01</span>
            <span class="theaters-booking-step-label">상영시간</span>
          </div>
          <div class="theaters-booking-step">
            <span class="theaters-booking-step-no">02</span>
            <span class="theaters-booking-step-label">인원/좌석</span>
          </div>
          <div class="theaters-booking-step">
            <span class="theaters-booking-step-no">03</span>
            <span class="theaters-booking-step-label">결제</span>
          </div>
          <div class="theaters-booking-step">
            <span class="theaters-booking-step-no">04</span>
            <span class="theaters-booking-step-label">결제완료</span>
          </div>
        </aside>

        <section class="theaters-booking-content">
          <div class="theaters-booking-topbar">
            <div class="theaters-booking-topcell">${escapeHtml(theater ? theater.theater_name : '극장')}</div>
            <div class="theaters-booking-topcell">${escapeHtml(movie ? movie.title : '영화')}</div>
            <div class="theaters-booking-topcell">${escapeHtml(selectedDateInfo ? `${selectedDateInfo.full}(${selectedDateInfo.week})` : '날짜')}</div>
          </div>

          <div class="theaters-booking-grid">
            <div class="theaters-booking-panel theaters-booking-region-panel"></div>
            <div class="theaters-booking-panel theaters-booking-theater-panel"></div>
            <div class="theaters-booking-panel theaters-booking-movie-panel"></div>
            <div class="theaters-booking-panel theaters-booking-date-panel"></div>
          </div>
        </section>
      </div>
    `;
  }

  function createLayoutElement() {
    const wrap = document.createElement('div');
    wrap.innerHTML = buildLayoutHtml().trim();
    return wrap.firstElementChild;
  }

  function cleanupDuplicatePages() {
    const pages = Array.from(document.querySelectorAll('.theaters-booking-page'));
    if (pages.length < 2) return;

    const preferred = pages.find((node) => !node.closest('#main-body')) || pages[0];
    pages.forEach((node) => {
      if (node !== preferred && node.closest('#main-body')) {
        node.remove();
      }
    });
  }

  function ensureLayoutRoot() {
    cleanupDuplicatePages();

    let root = document.querySelector('.theaters-booking-page');
    if (!root) {
      const mount = ensureMountPoint();
      mount.innerHTML = '';
      mount.appendChild(createLayoutElement());
      root = mount.querySelector('.theaters-booking-page');
    }

    const hasPanels = root.querySelector('.theaters-booking-region-panel')
      && root.querySelector('.theaters-booking-theater-panel')
      && root.querySelector('.theaters-booking-movie-panel')
      && root.querySelector('.theaters-booking-date-panel');

    if (!hasPanels) {
      const fresh = createLayoutElement();
      root.replaceWith(fresh);
      root = fresh;
    }

    return root;
  }

  function syncTopbar(root) {
    const theater = getTheaterById(state.selectedTheaterId);
    const detail = getSelectedTheaterDetail();
    const movie = getSelectedMovie(detail);
    const selectedDateInfo = formatDayLabel(state.selectedDateKey);
    const cells = root.querySelectorAll('.theaters-booking-topcell');

    if (cells[0]) cells[0].textContent = theater ? theater.theater_name : '극장';
    if (cells[1]) cells[1].textContent = movie ? movie.title : '영화';
    if (cells[2]) cells[2].textContent = selectedDateInfo ? `${selectedDateInfo.full}(${selectedDateInfo.week})` : '날짜';
  }

  function createSafeRenderHandler(handler) {
    return function () {
      Promise.resolve()
        .then(handler)
        .catch((error) => {
          console.error(error);
          alert(error.message || '화면 갱신 중 오류가 발생했습니다.');
        });
    };
  }

  function renderRegionPanel(container) {
    const regions = getRegions();

    container.innerHTML = `
      <div class="theaters-booking-panel-head">
        <button type="button" class="theaters-booking-tab is-active">전체</button>
      </div>
      <div class="theaters-booking-scroll theaters-booking-region-list"></div>
    `;

    const list = container.querySelector('.theaters-booking-region-list');

    regions.forEach((region) => {
      const button = document.createElement('button');
      button.type = 'button';
      button.className = `theaters-booking-list-button${region.name === state.selectedRegion ? ' is-active' : ''}`;
      button.innerHTML = `<span>${escapeHtml(region.name)}</span><span class="theaters-booking-list-count">(${region.count})</span>`;
      button.addEventListener('click', createSafeRenderHandler(async function () {
        state.selectedRegion = region.name;
        state.selectedTheaterId = null;
        state.selectedMovieId = null;
        state.selectedDateKey = '';
        state.selectedSpecial = 'ALL';
        state.selectedTimeBand = 'ALL';
        await render();
      }));
      list.appendChild(button);
    });
  }

  function renderTheaterPanel(container) {
    const theaters = getTheatersByRegion(state.selectedRegion);

    container.innerHTML = `
      <div class="theaters-booking-panel-head">
        <button type="button" class="theaters-booking-tab is-active">극장</button>
      </div>
      <div class="theaters-booking-scroll theaters-booking-theater-list"></div>
    `;

    const list = container.querySelector('.theaters-booking-theater-list');

    theaters.forEach((theater) => {
      const button = document.createElement('button');
      button.type = 'button';
      button.className = `theaters-booking-list-button${toInt(theater.theater_id) === toInt(state.selectedTheaterId) ? ' is-active' : ''}`;
      button.innerHTML = `
        <span>${escapeHtml(theater.theater_name)}</span>
        <span class="theaters-booking-check">${toInt(theater.theater_id) === toInt(state.selectedTheaterId) ? '✓' : ''}</span>
      `;
      button.addEventListener('click', createSafeRenderHandler(async function () {
        state.selectedTheaterId = toInt(theater.theater_id);
        state.selectedMovieId = null;
        state.selectedDateKey = '';
        state.selectedSpecial = 'ALL';
        state.selectedTimeBand = 'ALL';
        await render();
      }));
      list.appendChild(button);
    });
  }

  function renderMoviePanel(container, detail) {
    const movies = detail && Array.isArray(detail.movies) ? detail.movies : [];

    container.innerHTML = `
      <div class="theaters-booking-panel-head theaters-booking-panel-head-row">
        <select class="theaters-booking-select" id="theaters-booking-sort-select">
          <option value="ticketing">예매순</option>
        </select>
      </div>
      <div class="theaters-booking-scroll theaters-booking-movie-list"></div>
    `;

    const list = container.querySelector('.theaters-booking-movie-list');

    if (!movies.length) {
      list.innerHTML = '<div class="theaters-booking-empty">상영 가능한 영화가 없습니다.</div>';
      return;
    }

    movies.forEach((movie) => {
      const button = document.createElement('button');
      button.type = 'button';
      button.className = `theaters-booking-movie-button${toInt(movie.movie_id) === toInt(state.selectedMovieId) ? ' is-active' : ''}`;
      button.innerHTML = `
        <span class="theaters-booking-age">${escapeHtml(String(Math.max(0, toInt(movie.runtime_minutes || 0))).slice(0, 2).padStart(2, '0'))}</span>
        <span class="theaters-booking-movie-title">${escapeHtml(movie.title)}</span>
        <span class="theaters-booking-check">${toInt(movie.movie_id) === toInt(state.selectedMovieId) ? '✓' : ''}</span>
      `;
      button.addEventListener('click', createSafeRenderHandler(async function () {
        state.selectedMovieId = toInt(movie.movie_id);
        state.selectedDateKey = '';
        state.selectedSpecial = 'ALL';
        state.selectedTimeBand = 'ALL';
        await render();
      }));
      list.appendChild(button);
    });
  }

  function createDateButton(dateKey) {
    const info = formatDayLabel(dateKey);
    const todayKey = toDateKey(new Date());
    const button = document.createElement('button');
    button.type = 'button';
    button.className = `theaters-booking-date-button${dateKey === state.selectedDateKey ? ' is-active' : ''}`;
    button.innerHTML = `
      <span class="theaters-booking-date-day">${info ? info.day : '-'}</span>
      <span class="theaters-booking-date-week">${info ? info.week : '-'}</span>
      <span class="theaters-booking-date-today">${dateKey === todayKey ? '오늘' : '&nbsp;'}</span>
    `;
    button.addEventListener('click', createSafeRenderHandler(async function () {
      state.selectedDateKey = dateKey;
      await render();
    }));
    return button;
  }

  function createFilterButton(label, value, selectedValue, onClick) {
    const button = document.createElement('button');
    button.type = 'button';
    button.className = `theaters-booking-filter-button${value === selectedValue ? ' is-active' : ''}`;
    button.textContent = label;
    button.addEventListener('click', createSafeRenderHandler(async function () {
      onClick(value);
      await render();
    }));
    return button;
  }

  async function openScheduleDetail(schedule, movie, detail) {
    const hall = getHallByIdFromDetail(detail, schedule.hall_id) || {
      hall_id: schedule.hall_id,
      hall_name: schedule.hall_name || '상영관',
      total_seats: Math.max(1, toInt(schedule.total_count || DEFAULT_SEAT_ROWS * DEFAULT_SEAT_COLS)),
      seat_rows: DEFAULT_SEAT_ROWS,
      seat_cols: DEFAULT_SEAT_COLS
    };

    const theater = detail && detail.theater ? detail.theater : getTheaterById(state.selectedTheaterId);
    const reservedSeats = state.reservedSeatsMap[String(schedule.schedule_id)] || [];

    await ensureDetailScript();

    if (typeof window.openTheatersDetail !== 'function') {
      throw new Error('openTheatersDetail이 없습니다.');
    }

    const remainCount = getDisplayRemainCount(schedule);
    const scheduleForModal = {
      ...schedule,
      total_count: Math.max(0, toInt(schedule.total_count || hall.total_seats)),
      remain_count: remainCount
    };

    window.openTheatersDetail({
      schedule: scheduleForModal,
      hall,
      theater,
      movie,
      reservedSeats,
      onBooked(result) {
        const selectedSeats = Array.isArray(result && result.selectedSeats) ? result.selectedSeats : [];
        const seatStore = Array.isArray(state.reservedSeatsMap[String(schedule.schedule_id)])
          ? state.reservedSeatsMap[String(schedule.schedule_id)]
          : [];

        selectedSeats.forEach((seatKey) => {
          if (!seatStore.includes(seatKey)) {
            seatStore.push(seatKey);
          }
        });

        state.reservedSeatsMap[String(schedule.schedule_id)] = seatStore;

        const nextRemain = Math.max(0, remainCount - selectedSeats.length);
        state.remainOverrides[String(schedule.schedule_id)] = nextRemain;
        schedule.remain_count = nextRemain;

        render().catch((error) => {
          console.error(error);
        });
      }
    });
  }

  function createScheduleCard(schedule, movie, detail) {
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'theaters-booking-schedule-card';

    const rangeLabel = formatRangeLabel(schedule, movie);
    const specialTag = String(schedule.special_tag || buildSpecialTag(schedule.hall_name)).toUpperCase();
    const remainCount = getDisplayRemainCount(schedule);
    const totalCount = Math.max(0, toInt(schedule.total_count));

    button.innerHTML = `
      <div class="theaters-booking-schedule-time">${escapeHtml(rangeLabel)}</div>
      <div class="theaters-booking-schedule-meta">
        <span>${escapeHtml(schedule.hall_name || '상영관')}</span>
        <span>${escapeHtml(specialTag === 'GENERAL' ? '일반관' : specialTag)}</span>
      </div>
      <div class="theaters-booking-schedule-remain">잔여좌석 ${escapeHtml(String(remainCount))} / ${escapeHtml(String(totalCount))}</div>
    `;

    button.addEventListener('click', createSafeRenderHandler(async function () {
      await openScheduleDetail(schedule, movie, detail);
    }));

    return button;
  }

  function renderDatePanel(container, detail) {
    const dateKeys = state.selectedMovieId ? getAvailableDateKeys(detail, state.selectedMovieId) : [];
    const schedules = getSchedulesForSelection(detail);
    const selectedInfo = formatDayLabel(state.selectedDateKey);
    const monthLabel = state.selectedDateKey ? formatMonthLabel(state.selectedDateKey) : '';
    const selectedMovie = getSelectedMovie(detail);

    container.innerHTML = `
      <div class="theaters-booking-date-header">
        <div class="theaters-booking-month">${escapeHtml(monthLabel)}</div>
        <div class="theaters-booking-date-strip"></div>
      </div>
      <div class="theaters-booking-date-filters"></div>
      <div class="theaters-booking-date-divider"></div>
      <div class="theaters-booking-schedule-area"></div>
    `;

    const strip = container.querySelector('.theaters-booking-date-strip');
    const filters = container.querySelector('.theaters-booking-date-filters');
    const scheduleArea = container.querySelector('.theaters-booking-schedule-area');

    dateKeys.forEach((dateKey) => {
      strip.appendChild(createDateButton(dateKey));
    });

    const specialButtons = [
      { label: '전체', value: 'ALL' },
      { label: '일반관', value: 'GENERAL' },
      { label: 'Atmos', value: 'ATMOS' },
      { label: 'LASER', value: 'LASER' }
    ];

    const timeButtons = [
      { label: '전체', value: 'ALL' },
      { label: '13시 이후', value: 'AFTER_13' },
      { label: '19시 이후', value: 'AFTER_19' },
      { label: '심야', value: 'LATE' }
    ];

    const specialWrap = document.createElement('div');
    specialWrap.className = 'theaters-booking-filter-group';
    specialButtons.forEach((item) => {
      specialWrap.appendChild(createFilterButton(item.label, item.value, state.selectedSpecial, function (value) {
        state.selectedSpecial = value;
      }));
    });

    const timeWrap = document.createElement('div');
    timeWrap.className = 'theaters-booking-filter-group';
    timeButtons.forEach((item) => {
      timeWrap.appendChild(createFilterButton(item.label, item.value, state.selectedTimeBand, function (value) {
        state.selectedTimeBand = value;
      }));
    });

    filters.appendChild(specialWrap);
    filters.appendChild(timeWrap);

    if (!dateKeys.length) {
      scheduleArea.innerHTML = '<div class="theaters-booking-empty-large">조회 가능한 날짜가 없습니다.</div>';
      return;
    }

    if (!schedules.length) {
      scheduleArea.innerHTML = `
        <div class="theaters-booking-empty-large">
          <div class="theaters-booking-empty-icon">◌</div>
          <div>조회 가능한 상영시간이 없습니다.</div>
          <div>조건을 변경해주세요.</div>
        </div>
      `;
      return;
    }

    const groupMap = new Map();
    schedules.forEach((schedule) => {
      const key = schedule.hall_name || '상영관';
      if (!groupMap.has(key)) {
        groupMap.set(key, []);
      }
      groupMap.get(key).push(schedule);
    });

    groupMap.forEach((items, hallName) => {
      const group = document.createElement('section');
      group.className = 'theaters-booking-schedule-group';
      group.innerHTML = `
        <div class="theaters-booking-schedule-group-title">${escapeHtml(selectedInfo ? `${selectedInfo.full}(${selectedInfo.week})` : '')} · ${escapeHtml(hallName)}</div>
        <div class="theaters-booking-schedule-list"></div>
      `;

      const list = group.querySelector('.theaters-booking-schedule-list');
      items.forEach((schedule) => {
        list.appendChild(createScheduleCard(schedule, selectedMovie, detail));
      });
      scheduleArea.appendChild(group);
    });
  }

  async function render() {
    await ensureStateDefaults();

    const root = ensureLayoutRoot();
    const detail = getSelectedTheaterDetail();

    syncTopbar(root);
    renderRegionPanel(root.querySelector('.theaters-booking-region-panel'));
    renderTheaterPanel(root.querySelector('.theaters-booking-theater-panel'));
    renderMoviePanel(root.querySelector('.theaters-booking-movie-panel'), detail);
    renderDatePanel(root.querySelector('.theaters-booking-date-panel'), detail);
  }

  async function mountTheatersMain() {
    await ensureMainCss();

    if (window.APP_RUNTIME && typeof window.APP_RUNTIME.prefetchScripts === 'function') {
      window.APP_RUNTIME.prefetchScripts([THEATERS_DETAIL_SCRIPT_PATH]);
    }

    clearPrimarySections();

    const mount = ensureMountPoint();
    if (!document.querySelector('.theaters-booking-page')) {
      mount.innerHTML = '<div class="theaters-booking-page"><div class="theaters-booking-loading">예매 화면을 불러오는 중...</div></div>';
    }

    try {
      state.movies = await loadMovies();
      state.theaterList = await loadInitialDataset();
      state.theaterDetailMap = {};
      state.reservedSeatsMap = {};
      state.remainOverrides = await loadOptionalRemainOverrides();

      await render();
      window.scrollTo({ top: 0, left: 0, behavior: 'auto' });
    } catch (error) {
      console.error(error);
      mount.innerHTML = '<div class="theaters-booking-page"><div class="theaters-booking-error">예매 화면을 불러오지 못했습니다.</div></div>';
    }
  }

  // 수동 새로고침 훅
  // 나중에 잔여좌석 전용 py를 붙인 뒤 브라우저 콘솔에서
  // window.refreshTheatersRemainOverrides() 를 호출하면 다시 반영됩니다.
  window.refreshTheatersRemainOverrides = async function () {
    state.remainOverrides = await loadOptionalRemainOverrides();
    await render();
  };

  window.openTheatersMain = mountTheatersMain;
})();
